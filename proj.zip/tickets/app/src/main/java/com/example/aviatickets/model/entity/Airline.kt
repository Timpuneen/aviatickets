package com.example.aviatickets.model.entity

data class Airline(
    val name: String,
    val code: String
)